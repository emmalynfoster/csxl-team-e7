from enum import Enum

class Semester(Enum):
    SPRING = "SPRING"
    FALL = "FALL"
    SUMMER = "SUMMER"