# Treat `test` as a package.
