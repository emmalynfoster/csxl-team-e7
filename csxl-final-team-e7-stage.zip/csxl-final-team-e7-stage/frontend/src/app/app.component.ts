import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-navigation></app-navigation>'
})
export class AppComponent {
  title = 'frontend';
}
